package com.example.quiz.dto;

import com.example.quiz.entity.Quiz;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

@ToString
@Getter
@Setter
@Builder
@AllArgsConstructor
@RequiredArgsConstructor
public class QuizDTO {
    private Long id;

    @Size(min = 2,message = "이름은 2글자 이상으로 반드시 입력해야 합니다.")
    private String name;

    private String answer;

    @NotBlank(message = "퀴즈 내용은 공백일 수 없습니다.")
    private String quizContent;

    public static Quiz fromQuizDTO(QuizDTO dto){
        Quiz quiz = new Quiz();

        quiz.setId(dto.getId());
        quiz.setName(dto.getName());
        quiz.setAnswer(dto.getAnswer());
        quiz.setQuizContent(dto.getQuizContent());

        return quiz;
    }

    public static QuizDTO fromQuiz(Quiz quiz){
        return new QuizDTO(
                quiz.getId(),
                quiz.getName(),
                quiz.getAnswer(),
                quiz.getQuizContent()
                );
    }



}
