package com.example.quiz.service;

import com.example.quiz.dto.QuizDTO;
import com.example.quiz.entity.Quiz;
import com.example.quiz.repository.QuizRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class QuizService {
    private final QuizRepository quizRepository;

    public void saveQuiz(QuizDTO dto){
        Quiz quiz = QuizDTO.fromQuizDTO(dto);
        quizRepository.save(quiz);
    }

    public List<Quiz> getLists(){
        return quizRepository.findAll();
    }


    public Quiz findByIdFromQuiz(Long id) {
        return quizRepository.findById(id).orElse(null);
    }

    public void deleteQuiz(Long id) {
        quizRepository.deleteById(id);
    }

    public Quiz playQuiz(){
        return quizRepository.playRandomQuiz();
    }
}
