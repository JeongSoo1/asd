package com.example.quiz.controller;

import com.example.quiz.dto.QuizDTO;
import com.example.quiz.entity.Quiz;
import com.example.quiz.service.QuizService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping(value = "quiz")
public class QuizController {

    @Autowired
    QuizService quizService;

    @GetMapping("")
    public String showQuiz(Model model){
        model.addAttribute("dto", new QuizDTO());

        List<Quiz> quizList = quizService.getLists();
        model.addAttribute("lists",quizList);

        return "showQuiz";
    }

    @PostMapping("/insert")
    public String insert(@Valid @ModelAttribute("dto") QuizDTO dto,
                         BindingResult bindingResult,
                         Model model){
        if (bindingResult.hasErrors()){
            List<Quiz> quizList = quizService.getLists();
            model.addAttribute("lists",quizList);

            return "showQuiz";
        }
        quizService.saveQuiz(dto);
        return "redirect:/quiz";
    }

    @GetMapping("/update")
    public String showUpdateQuiz(@RequestParam("updateId")Long id, Model model){
        Quiz quiz = quizService.findByIdFromQuiz(id);
        QuizDTO dto = QuizDTO.fromQuiz(quiz);
        model.addAttribute("quiz",dto);

        return "updateQuiz";
    }

    @PostMapping("/update")
    public String updateQuiz(@Valid @ModelAttribute("quiz") QuizDTO dto,
                             BindingResult bindingResult){
        if (bindingResult.hasErrors()){
            return "updateQuiz";
        }
        quizService.saveQuiz(dto);
        return "redirect:/quiz";
    }

    @GetMapping("/delete")
    public String deleteQuiz(@RequestParam("deleteId")Long id){
        quizService.deleteQuiz(id);
        return "redirect:/quiz";
    }

    @GetMapping("/play")
    public String playQuiz(Model model){
        Quiz randomQuiz = quizService.playQuiz();
        model.addAttribute("quiz",randomQuiz);
        return "playQuiz";
    }

    @PostMapping("/check")
    public String checkQuiz(@RequestParam("checkedQuiz")String checkedQuiz,
                            @RequestParam("answer")String answer,
                            Model model){
        System.out.println("+++++++++++++++++++++checkedQuiz"+checkedQuiz);
        System.out.println("======================answer"+answer);
        boolean correct;
        if (answer.equals(checkedQuiz)){
            correct = true;
        }else {
            correct = false;
        }
        model.addAttribute("correct",correct);
        return "checkedQuiz";
    }
}
