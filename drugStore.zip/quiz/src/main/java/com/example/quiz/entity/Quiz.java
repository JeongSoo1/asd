package com.example.quiz.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "quiz")
@Data
public class Quiz extends BaseEntity{
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;

    @Column(length = 50,nullable = false)
    private String name;
    @Column(length = 500,nullable = false)
    private String quizContent;
    @Column(length = 10,nullable = false)
    private String answer;

}
