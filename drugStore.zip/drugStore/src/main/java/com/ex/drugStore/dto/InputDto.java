package com.ex.drugStore.dto;

import lombok.Data;

@Data
public class InputDto {
    private String address;

}
