package com.ex.drugStore.controller;

import com.ex.drugStore.dto.DocumentsDto;
import com.ex.drugStore.dto.InputDto;
import com.ex.drugStore.dto.KakaoApiResponseDto;
import com.ex.drugStore.dto.OutputDto;
import com.ex.drugStore.service.KakaoAddressSearchService;
import com.ex.drugStore.service.KakaoCategorySearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
public class MainController {
    @Autowired
    KakaoAddressSearchService kakaoAddressSearchService;
    @Autowired
    KakaoCategorySearchService kakaoCategorySearchService;
    @GetMapping("/")
    public String main(){
        return "main";
    }

    @PostMapping("/search")
    public String searchAddress(InputDto inputDto, Model model){
        KakaoApiResponseDto kakaoApiResponseDto = kakaoAddressSearchService.addressSearch(inputDto.getAddress());
        System.out.println(kakaoApiResponseDto);
        List<DocumentsDto> dtoList = new ArrayList<>();
        dtoList = kakaoApiResponseDto.getDocumentList();

        double logitude = dtoList.get(0).getLongitude();
        double latitude = dtoList.get(0).getLatitude();

//        System.out.println("=================="+logitude);
        KakaoApiResponseDto kakaoCategoryResult = kakaoCategorySearchService.resultCategorySearch(latitude, logitude);
        System.out.println(kakaoCategoryResult);

        List<OutputDto> outputDtoList = kakaoCategorySearchService.makeOutputDto(kakaoCategoryResult.getDocumentList());
        // 가장 가까운 거리에 있는 약국 3개만가져오기
        System.out.println("==========="+outputDtoList);
        model.addAttribute("list",outputDtoList);


        return "output";
    }
}
