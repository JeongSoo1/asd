package com.ex.drugStore.service;

import com.ex.drugStore.dto.DocumentsDto;
import com.ex.drugStore.dto.KakaoApiResponseDto;
import com.ex.drugStore.dto.OutputDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class KakaoCategorySearchService {
    @Autowired
    RestTemplate restTemplate;

    @Value("${kakao.rest.api.key}")
    private String kakaoRestApiKey;


    //약국 키워드
    private static final String CATEGORY = "PM9";

    private static final String KAKAO_CATEGORY_SEARCH_ADDRESS_URL = "https://dapi.kakao.com/v2/local/search/category.json";

    public KakaoApiResponseDto resultCategorySearch(
            double latitude, double longitude){
        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(KAKAO_CATEGORY_SEARCH_ADDRESS_URL);
        uriBuilder.queryParam("category_group_code",CATEGORY);
        uriBuilder.queryParam("x",longitude);
        uriBuilder.queryParam("y",latitude);
        uriBuilder.queryParam("radius",10000);
        uriBuilder.queryParam("sort", "distance");

        URI uri = uriBuilder.build().encode().toUri();
        org.springframework.http.HttpHeaders headers = new org.springframework.http.HttpHeaders();
        headers.add(HttpHeaders.AUTHORIZATION,"KakaoAK "+kakaoRestApiKey);

        HttpEntity<Object> httpEntity = new HttpEntity<>(headers);

        //카카오 api 호출
        return restTemplate.exchange(uri, HttpMethod.GET,httpEntity,KakaoApiResponseDto.class).getBody();

    }

    public List<OutputDto> makeOutputDto(List<DocumentsDto> documentList) {
//        List<OutputDto> outputDtoList = new ArrayList<>();
//        List<DocumentsDto> listThree = documentList.subList(0,3);
////        System.out.println(listThree);
//        for (DocumentsDto dto : listThree){
//            outputDtoList.add(OutputDto.fromDocumentDto(dto));
//        }
//        System.out.println(outputDtoList);
        if (ObjectUtils.isEmpty(documentList)){
            return null;
        }
        return documentList.stream()
                .limit(3)
                .map(OutputDto::fromDocumentDto)
                .collect(Collectors.toList());

    }
}
