package com.ex.drugStore.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class DocumentsDto {
    @JsonProperty("address_name")
    private String addressName;
    @JsonProperty("y") //위도
    private double latitude;
    @JsonProperty("x") //경도
    private double longitude;


    //추가
    @JsonProperty("place_name")
    private String placeName;
    @JsonProperty("phone")
    private String phone;
    @JsonProperty("distance")
    private double distance;

}
