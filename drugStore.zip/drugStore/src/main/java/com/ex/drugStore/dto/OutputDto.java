package com.ex.drugStore.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OutputDto {
    private String storeName; // 약국 이름
    private String storeAddress; // 약국 주소
    private String storePhone; //약국 전화번호
    private double distance; // 약국까지 거리
    private String mapUrl; // 약국 길찾기 URL
    private String roadViewUrl; // 로드뷰 URL

    public static OutputDto fromDocumentDto(DocumentsDto documentsDto){
        return OutputDto.builder()
                .storeName(documentsDto.getPlaceName())
                .storeAddress(documentsDto.getAddressName())
                .storePhone(documentsDto.getPhone())
                .distance(documentsDto.getDistance())
                //길찾기 URL
                .mapUrl("https://map.kakao.com/link/to/"+documentsDto.getPlaceName()+","+documentsDto.getLatitude()+","+documentsDto.getLongitude())
                //로드뷰 URL
                .roadViewUrl("https://map.kakao.com/link/roadview/"+documentsDto.getLatitude()+","+documentsDto.getLongitude())
                .build();
    }

}
