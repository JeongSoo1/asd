package com.example.basic.entity;

import jakarta.persistence.*;
import lombok.Data;

//데이터베이스와 1대1로 맵핑이되는 클래스
@Entity
@Table(name = "member")
@Data
public class Member extends BaseEntity{
//    자동증가 필드 타입은 Long
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(length = 40, nullable = false)
    private String name;
    private int age;
    @Column(length = 500)
    private String address;


}
