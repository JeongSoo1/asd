package com.example.basic.service;

import com.example.basic.dto.MemberDTO;
import com.example.basic.entity.Member;
import com.example.basic.repository.MemberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class MemberService {
    private final MemberRepository memberRepository;

    public List<Member> getLists() {
        return memberRepository.findAll();
    }

    public void saveMember(MemberDTO dto) {
        Member member = MemberDTO.fromMemberDTO(dto);
        memberRepository.save(member);
    }

    public void deleteMember(Long id) {
        memberRepository.deleteById(id);
    }

    public Member findByIdFromMember(Long id) {
        return memberRepository.findById(id).orElse(null);
    }

    public List<MemberDTO> searchName(String keyword) {
        List<Member> memberList = memberRepository.findByNameContains(keyword);
        List<MemberDTO> dtoList = new ArrayList<>();
        for (Member member : memberList){
            dtoList.add(MemberDTO.fromMember(member));
        }
        return dtoList;

//        return memberRepository.findByNameLike(keyword)
//                .stream()
//                .map(member -> MemberDTO.fromMember(member))
//                .collect(Collectors.toList());
    }

    public List<MemberDTO> searchAddress(String keyword) {
        return memberRepository.searchAddress(keyword)
                .stream()
                .map(member -> MemberDTO.fromMember(member))
                .collect(Collectors.toList());

    }
}
