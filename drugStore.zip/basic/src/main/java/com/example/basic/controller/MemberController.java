package com.example.basic.controller;

import com.example.basic.dto.MemberDTO;
import com.example.basic.entity.Member;
import com.example.basic.service.MemberService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Controller
@RequestMapping(value = "member")
public class MemberController {

    @Autowired
    MemberService memberService;

    @GetMapping("/list")
    public String showList(Model model){
        List<Member> memberList = memberService.getLists();
//        System.out.println(memberList);
        model.addAttribute("lists", memberList);
        model.addAttribute("title", "회원정보");

        return "showMember";
    }

    @GetMapping("/insertForm")
    public String showInsertForm(Model model){
        model.addAttribute("dto", new MemberDTO());
        return "insertMember";
    }

    @PostMapping("/insert")
    public String insert(@Valid @ModelAttribute("dto") MemberDTO dto, BindingResult bindingResult){
        if (bindingResult.hasErrors()){
            return  "insertMember";
        }
//        System.out.println("======insert : dto = " + dto);
        memberService.saveMember(dto);
        return "redirect:/member/list";
    }

    @GetMapping("/delete")
    public String delete(@RequestParam("deleteId")Long id){
//        System.out.println("============================deleteId = " + id);
        memberService.deleteMember(id);
        return "redirect:/member/list";
    }

    @GetMapping("/update")
    public String updateMember(@RequestParam("updateId")Long id, Model model) {
        Member member = memberService.findByIdFromMember(id);
        if (Objects.isNull(member)){
            return null;
        }
        MemberDTO dto = MemberDTO.fromMember(member);
        model.addAttribute("member",dto);
        return "updateMember";
    }

    @PostMapping("/update")
    public String update(@Valid @ModelAttribute("member") MemberDTO dto,
                             BindingResult bindingResult){
        if (bindingResult.hasErrors()){
            return "updateMember";
        }
//        System.out.println(dto);
        memberService.saveMember(dto);
        return "redirect:/member/list";
    }

    @GetMapping("/search")
    public String searchMember(@RequestParam("type")String type,
                               @RequestParam("keyword")String keyword,
                               Model model){
        List<MemberDTO> memberDTOList = new ArrayList<>();
        Member member = new Member();
        switch (type){
            case "id":
                //id로 검색 --> Member
                member = memberService.findByIdFromMember(Long.valueOf(keyword));
                //가져온 Member를 MemberDTO로 변환후 리스트에 추가
                memberDTOList.add(MemberDTO.fromMember(member));
                break;
            case "name":
                memberDTOList = memberService.searchName(keyword);
                break;
            case "address":
                memberDTOList = memberService.searchAddress(keyword);
                break;
            default:
                memberDTOList = memberService.getLists()
                        .stream()
                        .map(MemberDTO::fromMember)
                        .collect(Collectors.toList());
        }
        model.addAttribute("lists",memberDTOList);
        return "showMember";
    }
}
