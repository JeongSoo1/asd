package com.example.basic.repository;

import com.example.basic.entity.Member;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface MemberRepository extends JpaRepository<Member,Long> {
    List<Member> findByNameContains(String name);

    @Query(value = "SELECT * FROM member WHERE address LIKE %:keyword%",
    nativeQuery = true)
    List<Member> searchAddress(@Param("keyword")String keyword);
}
