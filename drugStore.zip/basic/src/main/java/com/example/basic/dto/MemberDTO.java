package com.example.basic.dto;

import com.example.basic.entity.Member;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.validator.constraints.Range;

@ToString
@Getter
@Setter
@Builder
@AllArgsConstructor
@RequiredArgsConstructor
public class MemberDTO {
    private Long id;
    @Size(min = 2,message = "이름은 2글자 이상으로 반드시 입력해야 합니다.")
    private String name;
    @Range(min =0 ,max = 120,message = "나이는 0세부터 120세까지 입니다.")
    private int age;
    @NotBlank(message = "주소는 꼭 입력해야 합니다.")
    private String address;

    public static Member fromMemberDTO(MemberDTO dto){
        Member member = new Member();
        member.setId(dto.getId());
        member.setName(dto.getName());
        member.setAge(dto.getAge());
        member.setAddress(dto.getAddress());

        return member;
    }

    public static MemberDTO fromMember(Member member){
//        this.id = member.getId();
//        this.name = member.getName();
        return new MemberDTO(
                member.getId(),
                member.getName(),
                member.getAge(),
                member.getAddress()
        );

    }
}
