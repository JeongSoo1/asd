package com.ex.myBatisBoard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyBatisBoardApplicationTests {

	@Test
	void contextLoads() {
	}

}
