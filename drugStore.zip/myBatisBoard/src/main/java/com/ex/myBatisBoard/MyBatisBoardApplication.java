package com.ex.myBatisBoard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyBatisBoardApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyBatisBoardApplication.class, args);
	}

}
