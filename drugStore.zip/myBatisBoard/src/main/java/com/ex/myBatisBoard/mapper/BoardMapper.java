package com.ex.myBatisBoard.mapper;

import com.ex.myBatisBoard.dto.BoardDto;
import com.ex.myBatisBoard.dto.BoardFileDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Mapper
public interface BoardMapper {
    List<BoardDto> findAll();

    BoardDto findById(Long id);

    void deleteById(Long id);

    void insertBoard(@Param("dto") BoardDto dto);

    void updateById(@Param("id") Long id, @Param("dto") BoardDto dto);

    void plusHitById(Long id);

    List<BoardDto> findByTitle(String keyword);

    List<BoardDto> findByName(String keyword);

    void saveFile(@Param("boardFileDto") BoardFileDto boardFileDto);

    List<BoardFileDto> findFile(Long id);
}
