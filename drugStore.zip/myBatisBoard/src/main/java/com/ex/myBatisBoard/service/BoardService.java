package com.ex.myBatisBoard.service;

import com.ex.myBatisBoard.dto.BoardDto;
import com.ex.myBatisBoard.dto.BoardFileDto;
import com.ex.myBatisBoard.mapper.BoardMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.List;

@Service
@RequiredArgsConstructor
public class BoardService {
    private final BoardMapper boardMapper;

    public List<BoardDto> findAll(){
        return boardMapper.findAll();
    }

    public BoardDto findById(Long id) {
        return boardMapper.findById(id);
    }

    public void deleteById(Long id) {
        boardMapper.deleteById(id);
    }

    public void insertBoard(BoardDto dto) throws IOException {
        if(dto.getBoardFile().get(0).isEmpty()){
            //파일 없음
            dto.setFileAttached(0);
            boardMapper.insertBoard(dto);
            System.out.println(dto);
        }else {
            //파일 있음
            dto.setFileAttached(1);
            //게시글 저장 후 id 값을 활용하기 위해서 id를 리턴 받음
            boardMapper.insertBoard(dto); //추가 수정 mapper, xml 부분
            System.out.println("======================="+dto);
            BoardDto savedBoard = boardMapper.findById(dto.getId());
            //파일 따로 가져오기
            for (MultipartFile boardFile : dto.getBoardFile()){
                String originalFileName = boardFile.getOriginalFilename();
                //저장용 파일 이름
                String storedFileName = System.currentTimeMillis() + "-" + originalFileName;

                // BoardFileDto 셋팅
                BoardFileDto fileDto = new BoardFileDto();
                fileDto.setOriginalFileName(originalFileName);
                fileDto.setStoredFileName(storedFileName);
                fileDto.setBoardId(savedBoard.getId());

                //파일 저장용 폴더에 파일들을 저장
                String savePath = "C:/upload_files/" + storedFileName;
                boardFile.transferTo(new File(savePath));

                // board_file_table에 저장처리
                boardMapper.saveFile(fileDto);

            }

        }

    }

    public void updateById(Long id, BoardDto dto) {
        boardMapper.updateById(id,dto);
    }

    public void plusHitById(Long id) {
        boardMapper.plusHitById(id);
    }

    public List<BoardDto> findByTitle(String keyword) {
        return boardMapper.findByTitle(keyword);
    }

    public List<BoardDto> findByName(String keyword) {
        return boardMapper.findByName(keyword);
    }

    public List<BoardFileDto> findFile(Long id) {
        return boardMapper.findFile(id);
    }
}
