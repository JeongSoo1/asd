package com.ex.myBatisBoard.controller;

import com.ex.myBatisBoard.dto.BoardDto;
import com.ex.myBatisBoard.dto.BoardFileDto;
import com.ex.myBatisBoard.service.BoardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Controller
public class BoardController {
    @Autowired
    BoardService boardService;

    @GetMapping("/")
    public String index(){
        return "index";
    }

    @GetMapping("/save")
    public String save(){
        return "save";
    }

    @PostMapping("/save")
    public String insertBoard(BoardDto dto) throws IOException {
        boardService.insertBoard(dto);
//        System.out.println(dto);
        return "redirect:/list";
    }

    @GetMapping("/list")
    public String findAllList(Model model){
        List<BoardDto> boardDtoList = boardService.findAll();
//        System.out.println(boardDtoList);
        model.addAttribute("lists",boardDtoList);
        return "list";
    }

    @GetMapping("/detail/{id}")
    public String detailList(@PathVariable("id")Long id,Model model){
//        System.out.println(id);
        boardService.plusHitById(id);
        BoardDto boardDto = boardService.findById(id);
        model.addAttribute("board",boardDto);
        System.out.println("XXXXXXXXXXXXXXX"+boardDto);
        if (boardDto.getFileAttached() == 1){
            List<BoardFileDto> boardFiles =  boardService.findFile(id);
            System.out.println("+==========="+boardFiles);
            model.addAttribute("boardFiles",boardFiles);
        }
//        System.out.println(boardDto);
        return "detail";
    }

    @GetMapping("/delete/{id}")
    public String deleteId(@PathVariable("id")Long id){
        boardService.deleteById(id);
        return "redirect:/list";
    }

    @GetMapping("/update/{id}")
    public String updateView(@PathVariable("id")Long id, Model model){
        BoardDto boardDto = boardService.findById(id);
        model.addAttribute("board",boardDto);
        return "update";
    }

    @PostMapping("/update/{id}")
    public String update(@PathVariable("id")Long id,BoardDto dto){
//        System.out.println(id);
//        System.out.println(dto);
        boardService.updateById(id,dto);

        return "redirect:/list";
    }

    @GetMapping("/search")
    public String search(@RequestParam("search")String searchType, @RequestParam("keyword")String keyword,
                         Model model){
        List<BoardDto> boardDtoList = new ArrayList<>();
        switch (searchType){
            case "title" :
                boardDtoList = boardService.findByTitle(keyword);
                break;
            case "name" :
                boardDtoList = boardService.findByName(keyword);
                break;
            default :
                boardDtoList = boardService.findAll();
        }
        model.addAttribute("lists",boardDtoList);
        return "list";
    }

}
