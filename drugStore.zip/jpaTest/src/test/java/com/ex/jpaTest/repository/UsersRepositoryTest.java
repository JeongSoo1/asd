package com.ex.jpaTest.repository;

import com.ex.jpaTest.constant.Gender;
import com.ex.jpaTest.entity.Users;
import org.assertj.core.util.Lists;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class UsersRepositoryTest {
    @Autowired
    UsersRepository usersRepository;

    @Test()
    void firstTest(){
        long count = (long) usersRepository.findAll().size();
        System.out.println("------------------"+count);
    }

    @Test()
    @DisplayName("findByName 테스트")
    void findByNameTest(){
        String findName = "Scotti";
        usersRepository.findByName(findName).forEach(System.out::println);
    }

    @Test()
    @DisplayName("findTop3ByLikeColor 테스트")
    void findTop3ByLikeColorTest(){
        String findcolor = "Pink";
        usersRepository.findTop3ByLikeColor(findcolor).forEach(x-> System.out.println(x));
    }

    @Test()
    @DisplayName("findByGenderAndLikeColor 테스트")
    void findByGenderAndLikeColorTest(){
        int resultSize = usersRepository.findByGenderAndLikeColor(Gender.Female,"Pink")
                .size();

        System.out.println("검색결과수: " + resultSize);

    }

    @Test()
    @DisplayName("findByCreatedAtGreaterThanEqual 테스트")
    void findByCreatedAtGreaterThanEqualTest(){
        LocalDateTime searchDate = LocalDateTime.now().minusDays(6);
        usersRepository.findByCreatedAtGreaterThanEqual(searchDate)
                .forEach(x-> System.out.println(x));
    }

    //최근 한달 검색
    @Test()
    @DisplayName("findByCreatedAtBetween 테스트")
    void findByCreatedAtBetweenTest(){
        LocalDateTime startDate = LocalDateTime.now().minusMonths(1L);
        LocalDateTime endDate = LocalDateTime.now();

        usersRepository.findByCreatedAtBetween(startDate,endDate)
                .forEach(x-> System.out.println(x));
    }

    @Test
    @DisplayName("findByLikeColorIn 테스트")
    void findByLikeColorIn(){
        usersRepository.findByLikeColorIn(Lists.newArrayList("Red","Orange"))
                .forEach(x-> System.out.println(x));
    }

    @Test
    @DisplayName("findByIdBetweenOrderByNameDesc 테스트")
    void findByIdBetweenOrderByName(){
        usersRepository.findByIdBetweenOrderByNameDesc(1L,10L).forEach(System.out::println);
    }

    @Test
    void findTop10ByLikeColor(){
        usersRepository.findTop10ByLikeColor("Orange",
                Sort.by(Sort.Order.asc("gender"),
                        Sort.Order.desc("CreatedAt")
                )).forEach(x-> System.out.println(x));
    }

    @Test
    @DisplayName("페이징 처리 테스트")
    void pagingTest(){
        System.out.println("페이지 = 0 , 페이지 당 : 5개씩");
        usersRepository.findAll(
                PageRequest.of(1,5,Sort.by(Sort.Order
                        .desc("name"))))
                .getContent().forEach(x-> System.out.println(x));
    }

    @Test
    void findByLikeColorTest(){
        Sort sort = Sort.by("createdAt").descending();
        Pageable pageable = PageRequest.of(0,10,sort);
        Page<Users> result = usersRepository.findByLikeColor("Orange",pageable);
        result.getContent().forEach(x-> System.out.println(x));
    }

    @Test
    @DisplayName("예제1")
    void findByGenderAndContaining(){
        usersRepository.findByGenderAndNameContainsOrGenderAndNameContains(
                Gender.Female, "w",Gender.Female,"m")
                .forEach(x-> System.out.println(x));
    }

    @Test
    @DisplayName("예제2")
    void findByEmailContains(){
        int result = usersRepository.findByEmailContains("net").size();
        System.out.println("net 포함 이메일 레코드 수"+result);
    }

    @Test
    @DisplayName("예제3")
    void findByCreatedAtGreaterThanEqualAndNameStartingWith(){
        LocalDateTime searchDate = LocalDateTime.now().minusMonths(1);
        usersRepository.findByUpdatedAtGreaterThanEqualAndNameStartingWith(searchDate,"J")
                .forEach(x-> System.out.println(x));
    }

    @Test
    @DisplayName("예제4")
    void findTop10ByCreatedAt(){
        List<Users> result = usersRepository.findTop10ByOrderByCreatedAtDesc();
        for (Users user : result){
            System.out.println(
                    "======================== "+
                    "ID : " + user.getId()+
                    ", Name : " + user.getName()+
                    ", Gender : " + user.getGender()+
                    ", CreatedAt : " + user.getCreatedAt()
            );
        }
    }

    @Test
    @DisplayName("예제5")
    void findByLikeColorAndGender(){
        List<Users> result = usersRepository.findByLikeColorAndGender("Red",Gender.Male);
        for (Users user : result){
            String account = user.getEmail();
            System.out.println(account + "의 계정 이름 : "+ account.substring(0,account.indexOf("@")));
        }
    }

    @Test
    @DisplayName("예제6")
    void exam06(){
        List<Users> usersLists = usersRepository.findAll();
        for (Users user : usersLists){
            if (user.getUpdatedAt().isBefore(user.getCreatedAt())){
                System.out.println(user);
            }
        }
    }

    @Test
    @DisplayName("예제7")
    void findByGenderAndEmailLikeOrderByCreatedAtDesc(){
        usersRepository.findByGenderAndEmailLikeOrderByCreatedAtDesc(Gender.Female,"%edu%")
                .forEach(x-> System.out.println(x));
    }

    @Test
    @DisplayName("예제8")
    void exam08(){
        usersRepository.findAll(
                Sort.by(Sort.Order.asc("likeColor"),
                        Sort.Order.desc("name"))
        ).forEach(x-> System.out.println(x));
    }

    @Test
    @DisplayName("예제9")
    void exam09(){
        usersRepository.findAll(
                PageRequest.of(0,10, Sort.by(Sort.Order.desc("CreatedAt")))
        ).forEach(x-> System.out.println(x));
    }

    @Test
    @DisplayName("예제10")
    void findByGenderOrderByIdDesc(){
        Pageable pageable = PageRequest.of(1,3);
        Page<Users> result =usersRepository.findByGenderOrderByIdDesc(Gender.Male, pageable);
        result.forEach(x-> System.out.println(x));
    }

    @Test
    @DisplayName("예제11")
    void findByCreatedAtBetween(){
        //기준일
        LocalDate baseDate = LocalDate.now().minusMonths(1L);
        //시작일
        LocalDateTime start = baseDate.withDayOfMonth(1).atTime(0,0,0);
        //종료일
        LocalDateTime end = baseDate.withDayOfMonth(baseDate.lengthOfMonth()).atTime(23,59,59);
        System.out.println("start: "+start + ", end" + end);

        usersRepository.findByCreatedAtBetween(start,end)
                .forEach(x-> System.out.println(x));

//        start,end).stream().filter(x->x.getId()==500L)
    }




}