package com.ex.jpaTest.service;

import com.ex.jpaTest.entity.Entertainment;
import com.ex.jpaTest.entity.Member;
import jakarta.persistence.EntityManager;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
class EntertainmentServiceTest {
    @Autowired
    EntertainmentService entertainmentService;

    @Autowired
    EntityManager em;

    @Test
    @DisplayName("엔터테이먼트 예제")
    void insertEGM(){
        entertainmentService.insertEGM();
        Member member = em.find(Member.class,"지수");
//        System.out.println(em.find(Member.class,"지수"));
        System.out.println("===========지수가 속한 걸그룹 이름과 엔터테이먼트 회사 이름 출력하기");
        System.out.println("소속 걸그룹 : "+member.getGirlGroup().getGroupName()+", 소속 회사 : "+member.getGirlGroup().getEntertainment().getEName());
    }
}