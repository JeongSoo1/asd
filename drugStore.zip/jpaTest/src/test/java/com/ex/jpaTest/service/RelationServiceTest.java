package com.ex.jpaTest.service;

import com.ex.jpaTest.entity.GirlGroup;
import com.ex.jpaTest.entity.Member;
import jakarta.persistence.EntityManager;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class RelationServiceTest {
    @Autowired
    RelationService relationService;
    @Autowired
    EntityManager em;

    @Test
    @DisplayName("insertMemberAndTeam")
    void insertMemberAndTeam() {
        relationService.insertMemberAndTeam();
    }

    //안유진의 팀 이름을 출력하시오
    // Member teamId 삭제
//    @Test
//    @DisplayName("안유진의 팀 이름 출력")
//    void teamNameDisplay() {
//        Member member1 = em.find(Member.class, "안유진");
//        GirlGroup girlGroup1 = em.find(GirlGroup.class , member1.getTeamId());
//        System.out.println("====================팀이름 : "+girlGroup1.getGroupName());
//    }

    @Test
    @DisplayName("insertMemberAndTeamRelation Test(fk)")
    void insertMemberAndTeamRelation(){
        relationService.insertMemberAndTeamRelation();
    }

    @Test
    @DisplayName("안유진의 팀 이름 출력")
    void teamNameDisplay() {
        Member member1 = em.find(Member.class, "안유진");
        System.out.println("====================팀이름 : "+member1.getGirlGroup().getGroupName());
    }

    @Test
    @DisplayName("insertBothDirectionRelation")
    void insertBothDirectionRelation(){
        relationService.insertBothDirectionRelation();
    }

    @Test
    @DisplayName("뉴진스 멤버이름 출력")
    void printNewJeansMember(){
        GirlGroup group = em.find(GirlGroup.class,"newJeans");
        List<Member> memberList = group.getMemberList();
        for(Member member : memberList){
            System.out.println("================================");
            System.out.println(member.getMemberName());
        }
    }

    @Test
    @DisplayName("insertListOnlyTest")
    void insertListOnlyTest(){
        relationService.insertListOnlyTest();
    }






}