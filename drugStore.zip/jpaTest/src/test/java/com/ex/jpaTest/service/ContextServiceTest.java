package com.ex.jpaTest.service;

import com.ex.jpaTest.entity.Member;
import jakarta.persistence.EntityManager;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class ContextServiceTest {
    @Autowired
    ContextService contextService;

    @Autowired
    EntityManager em;

    @Test
    @DisplayName("Context Test")
    void contextTest(){
        Member member = contextService.memberInsertAndReturn();

        System.out.println("=======================member : "+member);
    }

    @Test
    @DisplayName("영속성 보장 테스트")
    void persistContextTest(){
        Member jang1 = em.find(Member.class, "장원영");
        Member jang2 = em.find(Member.class, "장원영");

        System.out.println("두개의 인스턴스가 같은가?? "+jang1.equals(jang2));
    }


    @Test
    @DisplayName("Transaction Commit Test")
    void transactionCommitTest(){
        contextService.transactionTest();
    }


    @Test
    @DisplayName("더티 체킹 테스트")
    void dirtyCheckingTest(){
        contextService.dirtyCheckingTest();
    }

    @Test
    @DisplayName("remove Test")
    void removeTest(){
        contextService.removeTest();
    }

}