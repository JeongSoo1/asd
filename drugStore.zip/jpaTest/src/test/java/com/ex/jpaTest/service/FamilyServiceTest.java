package com.ex.jpaTest.service;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
class FamilyServiceTest {
    @Autowired
    FamilyService familyService;

    @Test
    @DisplayName("예제1 부모 자식관계")
    void test1(){
        familyService.test1();
    }

    @Test
    @DisplayName("CascadePersist_Test")
    void cascadeSave(){
        familyService.saveFamilyCascade();
    }

    @Test
    @DisplayName("deleteParent")
    void deleteParent(){
        familyService.deleteParent();
    }

    @Test
    @DisplayName("orphanRemoval")
    void orphanRemoval(){
        familyService.orphanRemoval();
    }

}