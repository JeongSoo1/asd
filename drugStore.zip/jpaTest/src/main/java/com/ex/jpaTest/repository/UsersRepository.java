package com.ex.jpaTest.repository;

import com.ex.jpaTest.constant.Gender;
import com.ex.jpaTest.entity.Users;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface UsersRepository extends JpaRepository<Users, Long> {
    //이름 검색을 통해 리스트로 반환
    List<Users> findByName(String name);

    //색상정보 중에 내가 정한 색상 리스트 중 상위 3개만 ...
    List<Users> findTop3ByLikeColor(String color);

    //입력한 성별과 색상을 만족하는 리스트 출력(Female 중에 Pink)
    List<Users> findByGenderAndLikeColor(Gender gender,String color);

    // 날짜검색 After, Before, Between 범위 검색
    // 7일전 데이터를 검색 - 당일 포함
    List<Users> findByCreatedAtGreaterThanEqual(LocalDateTime searchDate);

    //Between 키워드로 범위 검색하기
    List<Users> findByCreatedAtBetween(LocalDateTime startDate,
                                       LocalDateTime endDate);

    //select * from users where like_color in ('Yellow','Red');
    //in 구문을 이용해서 Red, Orange를 찾아봅니다.
    List<Users> findByLikeColorIn(List<String> colors);

    // Sort : id가 1~10인 자료를 찾고 얘네들을 이름 내림차순으로 정렬
    // select * from users where id between 1 and 10 order by name desc;
    List<Users> findByIdBetweenOrderByNameDesc(Long start,Long end);

    // Orange 색상 상위 10개 검색하고 Gender에 대해서 오름차순, CreatedAt에 대해서 내림
    // select * from users where like_color = 'Orange' order by gender asc, created_at desc limit 10;
    List<Users> findTop10ByLikeColor(String color, Sort sort);

    // Orange 색상 검색 후 페이지로 출력(0번째 페이지, 10개씩, CreatedAt 내림차순)
    Page<Users> findByLikeColor(String color, Pageable pageable);


    //예제
//    문제 1. 여성의 이름 중 "w"또는 "m"을 포함하는 자료를 검색하시오.
//    SELECT * FROM users WHERE Gender = 'Female' and (name LIKE '%w%' OR name LIKE '%m%')
    List<Users> findByGenderAndNameContainsOrGenderAndNameContains(Gender gender, String  name, Gender gender2,String name2);

//    문제 2. 이메일에 net을 포함하는 데이터 건수를 출력하시오.
//    SELECT count(*) FROM users WHERE Gender = "Woman" And name LIKE '%net%'
    List<Users> findByEmailContains(String email);


//    문제 3. 가장 최근 한달이내에 업데이트된 자료 중 이름 첫자가 "J"인 자료를 출력하시오.
//    like 써도 가능 "J%"
    List<Users> findByUpdatedAtGreaterThanEqualAndNameStartingWith(LocalDateTime searchDate, String name);

//    문제 4. 가장 최근 생성된 자료 10건을 ID, 이름, 성별, 생성일 만 출력하시오.
    List<Users> findTop10ByOrderByCreatedAtDesc();

//    문제 5. "Red"를 좋아하는 남성 이메일 계정 중 사이트를 제외한 계정만 출력하시오.
//            (예, apenley2@tripod.com  → apenley2)
    List<Users> findByLikeColorAndGender(String color,Gender gender);
//    문제 6. 갱신일이 생성일 이전인 잘못된 데이터를 출력하시오.
//    exam06

//    문제 7. 이메일에 edu를 갖는 여성 데이터를 가장 최근 데이터부터 보이도록 출력하시오.
    List<Users> findByGenderAndEmailLikeOrderByCreatedAtDesc(Gender gender,String email);

//    문제 8. 좋아하는 색상(Pink)별로 오름차순 정렬하고 같은 색상 데이터는 이름의 내림차순으로 출력하시오.
// exam08

//    문제 9. 전체 자료를 가장 최근 입력한 자료 순으로 정렬 및 페이징 처리하고 한 페이지당 10건씩 출력하되,
//    그 중 1번째 페이지를 출력하시오.


//    문제10. 남성 자료를 ID의 내림차순으로 정렬한 후 한페이당 3건을 출력하되 그 중 2번째 페이지 자료를  출력하시오.
    Page<Users> findByGenderOrderByIdDesc(Gender gender,Pageable pageable);

//    문제11. 지난달의 모든 자료를 검색하여 출력하시오. 6/1~ 6-31
//List<Users> findByCreatedAtBetween
}
