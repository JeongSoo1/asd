package com.ex.jpaTest.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Entity
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Member {
    @Id
    private String memberId;  //jangwonyoung
    private String memberName; //장원영

    @ManyToOne
    @JoinColumn(name = "groupId")
    private GirlGroup girlGroup;

}
