package com.ex.jpaTest.service;

import com.ex.jpaTest.entity.Member;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ContextService {
    @Autowired
    EntityManager em;

    @Transactional
    public Member memberInsertAndReturn(){
        Member member = Member.builder()
                .memberId("장원영")
                .memberName("원영이")
                .build();
        em.persist(member);

        Member m = em.find(Member.class, "장원영");
        return m;
    }

    @Transactional
    public void transactionTest(){
        Member hong = Member.builder()
                .memberId("홍길동")
                .memberName("길똥이")
                .build();

        Member lee = Member.builder()
                .memberId("이순신")
                .memberName("순신이")
                .build();

        em.persist(hong);
        em.persist(lee);
        em.flush();
    }

    @Transactional
    public void dirtyCheckingTest(){
        //영속성 엔티티 조회
        Member jang = em.find(Member.class, "장원영");
        //이름 수정
        jang.setMemberName("JangWonYoung");
    }

    @Transactional
    public void removeTest(){
        Member hong = em.find(Member.class, "홍길동");
        em.remove(hong);


    }
}
