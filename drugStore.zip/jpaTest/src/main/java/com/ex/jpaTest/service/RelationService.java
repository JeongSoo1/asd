package com.ex.jpaTest.service;

import com.ex.jpaTest.entity.Child;
import com.ex.jpaTest.entity.GirlGroup;
import com.ex.jpaTest.entity.Member;
import com.ex.jpaTest.entity.Parent;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import lombok.Builder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class RelationService {
    @Autowired
    EntityManager em;

    @Transactional
    public void insertMemberAndTeam() {
        Member member = Member.builder()
                .memberId("안유진")
                .memberName("유진")
//                .teamId("ive")
                .build();

        GirlGroup girlGroup = GirlGroup.builder()
                .groupId("ive")
                .groupName("아이브")
                .build();
        em.persist(member);
        em.persist(girlGroup);
    }

    @Transactional
    public void insertMemberAndTeamRelation() {
        GirlGroup ive = GirlGroup.builder()
                .groupId("ive")
                .groupName("아이브")
                .build();
        em.persist(ive);

        Member member = Member.builder()
                .memberId("안유진")
                .memberName("유진")
                .girlGroup(ive)
                .build();

        em.persist(member);
    }

    @Transactional
    public void insertBothDirectionRelation(){
        //뉴진스 그룹 생성
        GirlGroup newJeans = GirlGroup.builder()
                .groupId("newJeans")
                .groupName("뉴진스")
                .build();
        em.persist(newJeans);

        //민지 생성
        Member minji = Member.builder()
                .memberId("민지")
                .memberName("MinJi")
                .girlGroup(newJeans)
                .build();
        newJeans.getMemberList().add(minji);
        em.persist(minji);
        //혜인 생성
        Member haein = Member.builder()
                .memberId("혜인")
                .memberName("HaeIn")
                .girlGroup(newJeans)
                .build();
        newJeans.getMemberList().add(haein);
        em.persist(haein);
    }

    @Transactional
    public void insertListOnlyTest(){


        //씨름팀 생성 후 이만기, 강호동을 리스트에 추가하기
        GirlGroup ssirum = GirlGroup.builder()
                .groupId("ssium")
                .groupName("씨름팀")
                .build();
        em.persist(ssirum);


        //이만기 생성
        Member mangi = Member.builder()
                .memberId("이만기")
                .memberName("만기")
                .girlGroup(ssirum)
                .build();
        ssirum.getMemberList().add(mangi);
        em.persist(mangi);
        //강호동 생성
        Member hodong = Member.builder()
                .memberId("강호동")
                .memberName("호동")
                .girlGroup(ssirum)
                .build();
        ssirum.getMemberList().add(hodong);
        em.persist(hodong);

        List<Member> memberList = ssirum.getMemberList();

        System.out.println(memberList);
    }









}
