package com.ex.jpaTest.entity;

import com.ex.jpaTest.constant.Gender;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class Users extends BaseEntity{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(length = 50)
    private String name;
    @Column(length = 50)
    private String email;
    @Enumerated(EnumType.STRING)
    private Gender gender;
    @Column(length = 50)
    private String likeColor;

}
