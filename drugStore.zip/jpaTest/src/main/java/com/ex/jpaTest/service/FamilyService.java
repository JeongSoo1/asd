package com.ex.jpaTest.service;

import com.ex.jpaTest.entity.Child;
import com.ex.jpaTest.entity.Parent;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FamilyService {

    @Autowired
    EntityManager em;

    @Transactional
    public void test1(){
        Parent parent1 = Parent.builder()
                .pName("father")
                .build();
        em.persist(parent1);

        Child child1 = Child.builder()
                .cName("톰")
                .parent(parent1)
                .build();
        parent1.getChildList().add(child1);
        em.persist(child1);

        Child child2 = Child.builder()
                .cName("밥")
                .parent(parent1)
                .build();
        parent1.getChildList().add(child2);
        em.persist(child2);

        parent1.getChildList().forEach(x-> System.out.println(x));
    }

    @Transactional
    public void saveFamilyCascade(){


        Child child1 = Child.builder()
                .cName("자식3")
                .build();

        Child child2 = Child.builder()
                .cName("자식4")
                .build();

        Parent parent = Parent.builder()
                .pName("부모2")
                .build();
        child1.setParent(parent);
        child2.setParent(parent);
        parent.getChildList().add(child1);
        parent.getChildList().add(child2);
        em.persist(parent);




        parent.getChildList().forEach(System.out::println);
    }

    @Transactional
    public void deleteParent(){
        Parent parent = em.find(Parent.class,2L);
        em.remove(parent);
    }

    @Transactional
    public void orphanRemoval(){
        Parent parent = em.find(Parent.class,null);
        parent.getChildList().remove(1);
    }


}
