package com.ex.jpaTest.service;

import com.ex.jpaTest.entity.Entertainment;
import com.ex.jpaTest.entity.GirlGroup;
import com.ex.jpaTest.entity.Member;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EntertainmentService {
    @Autowired
    EntityManager em;

    @Transactional
    public void insertEGM(){
        Member member1 = Member.builder()
                .memberId("안유진")
                .memberName("유진")
                .build();

        Member member2 = Member.builder()
                .memberId("장원영")
                .memberName("원영")
                .build();

        Member member3 = Member.builder()
                .memberId("제니")
                .memberName("째니")
                .build();

        Member member4 = Member.builder()
                .memberId("지수")
                .memberName("지수다")
                .build();

        GirlGroup ive = GirlGroup.builder()
                .groupId("ive")
                .groupName("아이브")
                .build();
        member1.setGirlGroup(ive);
        member2.setGirlGroup(ive);
        ive.getMemberList().add(member1);
        ive.getMemberList().add(member2);

        GirlGroup blackPink = GirlGroup.builder()
                .groupId("blackPink")
                .groupName("블핑")
                .build();
        member3.setGirlGroup(blackPink);
        member4.setGirlGroup(blackPink);
        blackPink.getMemberList().add(member3);
        blackPink.getMemberList().add(member4);

        Entertainment starship = Entertainment.builder()
                .eId("starship")
                .eName("스타쉽")
                .build();
        ive.setEntertainment(starship);
        starship.getGirlGroupList().add(ive);

        Entertainment yg = Entertainment.builder()
                .eId("yg")
                .eName("와이지")
                .build();
        blackPink.setEntertainment(yg);
        yg.getGirlGroupList().add(blackPink);

        em.persist(yg);
        em.persist(starship);

    }
}
