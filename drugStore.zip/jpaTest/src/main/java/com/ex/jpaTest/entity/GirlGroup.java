package com.ex.jpaTest.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class GirlGroup {
    @Override
    public String toString() {
        return "GirlGroup{" +
                "groupId='" + groupId + '\'' +
                ", groupName='" + groupName + '\'' +
                '}';
    }

    @Id
    private String groupId;
    private String groupName;

    @Builder.Default
    @OneToMany(mappedBy = "girlGroup", fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
    private List<Member> memberList = new ArrayList<>();

    @ManyToOne
    @JoinColumn(name = "eId")
    private Entertainment entertainment;

}
