package com.ex.jpaTest.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Builder
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class Parent {
    @Override
    public String toString() {
        return "Parent{" +
                "pId=" + pId +
                ", pName='" + pName + '\'' +
                '}';
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long pId;
    private String pName;

    @Builder.Default
    @OneToMany(mappedBy = "parent",cascade = {CascadeType.PERSIST , CascadeType.REMOVE}
    ,orphanRemoval = true)
    List<Child> childList = new ArrayList<>();

}
