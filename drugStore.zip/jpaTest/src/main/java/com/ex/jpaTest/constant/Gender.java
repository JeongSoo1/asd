package com.ex.jpaTest.constant;

public enum Gender {
    Male, Female
}
