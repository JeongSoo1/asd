package com.ex.jpaTest.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Entertainment {
    @Id
    private String eId;
    private String eName;

    @Builder.Default
    @OneToMany(mappedBy = "entertainment",fetch = FetchType.EAGER,cascade = CascadeType.PERSIST)
    List<GirlGroup> girlGroupList = new ArrayList<>();

}
