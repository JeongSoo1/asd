package com.ex.myboard.api;

import com.ex.myboard.dto.ArticleDto;
import com.ex.myboard.entity.Article;
import com.ex.myboard.service.ArticleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ArticleApiController {
    @Autowired
    ArticleService articleService;

    @GetMapping("/api/articles/{id}")
    public ArticleDto getListOne(@PathVariable("id") Long id) {
        return articleService.findArticleById(id);
    }
}
