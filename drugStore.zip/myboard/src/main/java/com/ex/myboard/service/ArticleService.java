package com.ex.myboard.service;

import com.ex.myboard.dto.ArticleDto;
import com.ex.myboard.dto.CommentDto;
import com.ex.myboard.entity.Article;
import com.ex.myboard.entity.Comment;
import com.ex.myboard.repository.ArticleRepository;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ArticleService {
    @Autowired
    EntityManager em;

    @Autowired
    ArticleRepository articleRepository;

    public List<ArticleDto> findAllArticle(){
        return articleRepository.findAll().stream()
                //.map(article -> ArticleDto.fromEntityToDto(article))
                .map(ArticleDto::fromEntityToDto)
                .collect(Collectors.toList());
    }

    @Transactional
    public ArticleDto findArticleById(Long id){
        Article article = em.find(Article.class,id);
        ArticleDto dto;
        dto = ArticleDto.fromEntityToDto(article);
        System.out.println("=========================="+dto);
        return dto;
//        System.out.println("=============="+article.getCommentList());
//        articleRepository.findById(id);
//        ArticleDto.fromEntityToDto(articleRepository.findById(id).orElse(null));

    }

    @Transactional
    public void saveContent(ArticleDto articleDto) {
//        articleRepository.save(ArticleDto.fromDtoToEntity(articleDto));
        Article article = ArticleDto.fromDtoToEntity(articleDto);
        em.persist(article);

    }

    @Transactional
    public void deleteByArticleId(Long id) {
        Article article = em.find(Article.class,id);
        em.remove(article);
//        articleRepository.deleteById(id);
    }

    @Transactional
    public void updateArticle(ArticleDto dto) {
        Article article = em.find(Article.class, dto.getId());
        article.setTitle(dto.getTitle());
        article.setContent(dto.getContent());
    }

    public CommentDto getOneComment(Long commentId){
        Comment comment = em.find(Comment.class, commentId);
        CommentDto dto = new CommentDto();
        dto.setCommentId(comment.getCommentId());
        dto.setArticleId(comment.getArticle().getId());
        dto.setNickname(comment.getNickname());
        dto.setBody(comment.getBody());
        return dto;
    }

    public Page<Article> PagingList(Pageable pageable) {
        return articleRepository.findAll(pageable);
    }
}
