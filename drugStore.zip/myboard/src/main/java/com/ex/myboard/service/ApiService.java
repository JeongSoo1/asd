package com.ex.myboard.service;

import com.ex.myboard.dto.CommentDto;
import com.ex.myboard.entity.Article;
import com.ex.myboard.entity.Comment;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Table;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ApiService {
    @Autowired
    EntityManager em;
    public List<CommentDto> getComments(Long id) {
        Article article = em.find(Article.class,id);
        List<CommentDto> commentDtoList = new ArrayList<>();
        for (Comment comment : article.getCommentList()){
            CommentDto dto = new CommentDto();
            dto.setArticleId(id);
            dto.setCommentId(comment.getCommentId());
            dto.setNickname(comment.getNickname());
            dto.setBody(comment.getBody());
            commentDtoList.add(dto);
        }
        return commentDtoList;
    }

    @Transactional
    public void createComment(Long articleId, CommentDto dto) {
        Article article = em.find(Article.class,articleId);
        Comment comment = new Comment();
        comment.setNickname(dto.getNickname());
        comment.setBody(dto.getBody());
        comment.setArticle(article);
        article.getCommentList().add(comment);
    }

    @Transactional
    public void deleteComment(Long commentId) {
        Comment comment = em.find(Comment.class,commentId);
        em.remove(comment);
    }

    @Transactional
    public void updateComment(Long commentId,CommentDto dto){
        Comment comment = em.find(Comment.class,commentId);
        comment.setNickname(dto.getNickname());
        comment.setBody(dto.getBody());
    }
}
