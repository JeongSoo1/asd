package com.ex.myboard.controller;

import com.ex.myboard.dto.ArticleDto;
import com.ex.myboard.dto.CommentDto;
import com.ex.myboard.entity.Article;
import com.ex.myboard.service.ArticleService;
import com.ex.myboard.service.PaginationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("articles")
public class ArticleController {
    @Autowired
    ArticleService articleService;
    @Autowired
    PaginationService paginationService;

    @GetMapping("/paging")
    public String paging(Model model, @PageableDefault(page = 0,size = 10,sort = "id",
            direction = Sort.Direction.DESC)Pageable pageable){
        Page<Article> paging = articleService.PagingList(pageable);
        int totalPage = paging.getTotalPages();
        //페이지 블럭 요청
        List<Integer> barNumbers = paginationService.getPaginationBarNumbers(pageable.getPageNumber(), totalPage);
//        List<ArticleDto> allArticle = articleService.findAllArticle();
//        model.addAttribute("list",allArticle);
        model.addAttribute("paging",paging);
        model.addAttribute("barNumbers",barNumbers);
        return "show_all_list";
    }

    @GetMapping("")
    public String showAllArticles(Model model){
        List<ArticleDto> allArticle = articleService.findAllArticle();
        model.addAttribute("list",allArticle);
        return "show_all";
    }

    @GetMapping("/{id}")
    public String showFindById(@PathVariable("id") Long id, Model model){
        ArticleDto article = articleService.findArticleById(id);
        model.addAttribute("article",article);
        return "show";
    }

    @GetMapping("/new")
    public String showCreateForm(){
        return "new";
    }

    @PostMapping("/create")
    public String createNewContent(ArticleDto dto){
        System.out.println("=================="+dto);
        articleService.saveContent(dto);
        return "redirect:/articles";
    }

    @GetMapping("/{id}/delete")
    public String deleteById(@PathVariable("id") Long id){
        articleService.deleteByArticleId(id);
        return "redirect:/articles";
    }

    @GetMapping("/{id}/update")
    public String showUpdateForm(@PathVariable("id") Long id, Model model){
        ArticleDto article = articleService.findArticleById(id);
        model.addAttribute("article", article);
        return "update";
    }

    @PostMapping("/update")
    public String updateArticle(ArticleDto dto){
//        articleService.saveContent(dto);
        System.out.println(dto);
        articleService.updateArticle(dto);
        return "redirect:/articles";

    }


}
