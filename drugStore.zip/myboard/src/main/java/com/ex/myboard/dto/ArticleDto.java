package com.ex.myboard.dto;

import com.ex.myboard.entity.Article;
import com.ex.myboard.entity.Comment;
import lombok.*;

import java.beans.ConstructorProperties;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@RequiredArgsConstructor
public class ArticleDto {
    private Long id;
    private String title;
    private String content;
    private List<Comment> commentList;

    public static Article fromDtoToEntity(ArticleDto dto){
        Article article = new Article();
        article.setId(dto.id);
        article.setTitle(dto.getTitle());
        article.setContent(dto.getContent());
        return article;
    }

    public static ArticleDto fromEntityToDto(Article article){
        return new ArticleDto(
                article.getId(),
                article.getTitle(),
                article.getContent(),
                article.getCommentList()
        );
    }


}
