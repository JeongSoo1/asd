package com.ex.myboard.dto;

import com.ex.myboard.entity.Article;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Data;

@Data
public class CommentDto {
    private Long commentId;
    private Long articleId;
    private String nickname;
    private String body;
}
