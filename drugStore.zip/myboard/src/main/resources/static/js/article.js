$(document).ready(function () {
    $("#comment-update-btn").on("click", ()=>{
            const comment = {
                nickname: $('#update-comment-nickname').val(),
                body: $('#update-comment-body').val(),
                articleId: $('#article-id').val(),
                commentId : $('#comment-id').val(),
            }
//            console.log(comment)
//            console.log('/api/comments/' + comment.commentId)
//            console.log('/articles/' + comment.articleId)
            $.ajax({
                type: 'PATCH',
                url: '/api/comments/' + comment.commentId,
                async: true,
                headers: {
                    'Content-Type': 'application/json',
                },
                dataType: 'json',
                data: JSON.stringify(comment),
                success: () => {
                    alert('댓글이 수정됐습니다.');
                    window.location.href = '/articles/' + comment.articleId
                },
                error: function (request, status, error) {
                    alert('댓글 수정에 실패했습니다. 관리자에게 문의하세요.');
                }
            });
    });


    $(document).on("click", "#comment-delete-btn" , function(){
        let deleteCommentId = $(this).next().val();
//        alert("삭제 버튼 클릭 id ====" + deleteCommentId);
        $.ajax({
            type : 'DELETE',
            url : '/api/comments/'+deleteCommentId,
            async: true,
            headers: {
                'Content-Type': 'application/json',
            },
            dataType: 'text',
            success: () => {
                alert('댓글이 삭제되었습니다.');
                window.location.reload();
            },
            error: function (request, status, error) {
                alert('댓글 삭제에 실패했습니다. 관리자에게 문의하세요.');
            }

        })
    });



    $('#comment-create-btn').on('click', function () {
        const comment = {
            nickname: $('#new-comment-nickname').val(),
            body: $('#new-comment-body').val(),
            articleId: $('#new-comment-article-id').val()
        }
        let sendUrl = '/api/articles/' + comment.articleId + '/comments';
        $.ajax({
            type: 'POST',
            url: sendUrl,
            async: true,
            headers: {
                'Content-Type': 'application/json',
            },
            dataType: 'json',
            data: JSON.stringify(comment),
            success: () => {
                alert('댓글이 등록됐습니다.');
                window.location.reload();
            },
            error: function (request, status, error) {
                alert('댓글 등록에 실패했습니다. 관리자에게 문의하세요.');
            }
        })
    });


});
