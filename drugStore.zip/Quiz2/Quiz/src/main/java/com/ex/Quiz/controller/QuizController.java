package com.ex.Quiz.controller;

import com.ex.Quiz.dto.QuizDto;
import com.ex.Quiz.service.QuizService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
public class QuizController {

    @Autowired
    QuizService quizService;

    @GetMapping("/")
    public String mainList(Model model) {
        List<QuizDto> quizList = quizService.getAllQuizList();
        model.addAttribute("quizList",quizList);
        return "quizList";
    }
    @GetMapping("/quiz/insert")
    public String quizInsert(){
        return "quizForm";
    }

    @PostMapping("/quiz/insert")
    public String insertQuiz(QuizDto dto){
//        System.out.println(dto);
        quizService.saveQuiz(dto);
        return "redirect:/";
    }

    @PostMapping("/quiz/delete/{id}")
    public String deleteQuiz(@PathVariable("id")Long id){
        quizService.deleteQuiz(id);
        return "redirect:/";
    }

    @PostMapping("/quiz/update/{id}")
    public String updateQuizForm(@PathVariable("id")Long id,
                                 Model model){
        QuizDto quiz = quizService.getOneQuiz(id);
        model.addAttribute("quiz",quiz);
        return "quizFormUpdate";
    }

    @PostMapping("/quiz/update")
    public String updateQuiz(QuizDto dto){
//        System.out.println(dto+"====================");
        quizService.saveQuiz(dto);
        return "redirect:/";
    }

    @GetMapping("/quiz/play")
    public String quizForm(Model model){
        QuizDto quiz = quizService.getRandomQuiz();
        model.addAttribute("quiz",quiz);
        return "play";
    }

    @PostMapping("/quiz/solve")
    public String solveQuiz(QuizDto dto, RedirectAttributes attributes){
        System.out.println(dto+"=====================================");
        String msg = quizService.confirmAnswer(dto);
        attributes.addFlashAttribute("msg", msg);
        return "redirect:/quiz/play";
    }






}
