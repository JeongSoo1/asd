package com.ex.Quiz.service;

import com.ex.Quiz.dto.QuizDto;
import com.ex.Quiz.entity.Quiz;
import com.ex.Quiz.repository.QuizRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;


import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class QuizService {
    @Autowired
    QuizRepository quizRepository;

    public void saveQuiz(QuizDto dto){
        quizRepository.save(QuizDto.fromDtoToEntity(dto));
    }

    public List<QuizDto> getAllQuizList(){
        return quizRepository.findAll().stream()
                .map(QuizDto::fromEntityToDto)
                .collect(Collectors.toList());
    }

    public void deleteQuiz(Long id) {
        quizRepository.deleteById(id);
    }

    public QuizDto getOneQuiz(Long id) {
        Quiz quizEntity =quizRepository.findById(id).orElse(null);
        if (ObjectUtils.isEmpty(quizEntity)) return  null;
        return QuizDto.fromEntityToDto(quizEntity);
    }

    public QuizDto getRandomQuiz(){
        Quiz quiz = quizRepository.getRandomQuiz().orElse(null);
        if (ObjectUtils.isEmpty(quiz)){
            return null;
        }else{
            return QuizDto.fromEntityToDto(quiz);
        }
    }

    public String confirmAnswer(QuizDto dto) {
        Quiz quiz = quizRepository.findById(dto.getId()).orElse(null);
        if (dto.isAnswer() == Objects.requireNonNull(quiz).isAnswer()){
            return "정답입니다.";
        }else {
            return "오답입니다";
        }
    }
}
