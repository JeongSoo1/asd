package com.ex.Quiz.dto;

import com.ex.Quiz.entity.Quiz;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;


@Data
@AllArgsConstructor
public class QuizDto {
    private Long id;
    private String question;
    private boolean answer;
    private String author;

    public static Quiz fromDtoToEntity(QuizDto dto){
        Quiz quiz = new Quiz();
        quiz.setId(dto.id);
        quiz.setQuestion(dto.getQuestion());
        quiz.setAnswer(dto.answer);
        quiz.setAuthor(dto.getAuthor());

        return quiz;
    }

    public static QuizDto fromEntityToDto(Quiz quiz){
        return new QuizDto(
                quiz.getId(),
                quiz.getQuestion(),
                quiz.isAnswer(),
                quiz.getAuthor()
        );
    }


}
