package com.ex.Quiz.repository;

import com.ex.Quiz.entity.Quiz;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface QuizRepository extends JpaRepository<Quiz, Long> {
    @Query(value = "select * from quiz order by rand() limit 1", nativeQuery = true)
    Optional<Quiz> getRandomQuiz();
}
