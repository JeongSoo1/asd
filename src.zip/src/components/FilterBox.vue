<template>
    <div @click="changeFilter" :class="`${filter} filter-item`" 
    :style="{backgroundImage : `url(${strUrl})`}">
        <slot></slot>
        <!-- <button @click="fire">발사</button> -->
    </div>
</template>

<script>

export default {
    name : "FliterBoxVue",
    props : {
        strUrl : String,
        filter : String,
    },
    methods : {
        fire(){
            this.emitter.emit("fire","총");
        },
        changeFilter(){
            this.emitter.emit("changeFilter", this.filter );
        }
    }
}
</script>

<style>
    .filter-item{
        width: 100px;
        height: 100px;
        margin: 10px 10px 10px auto;
        padding: 8px;
        display: inline-block;
        color: white;
        background-size: cover;
        background-position: center;
    }
</style>