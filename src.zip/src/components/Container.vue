<template>
    <!-- step == 0 일때 -->
    <div v-if="step == 0">
        <Post v-for="post in postData" :key="post" :post="post" />
    </div>
  <!-- step == 1 일때  : 이미지 선택 및 필터 적용-->
    <div v-if="step == 1">
        <div :class="`${newFilter} upload-image`" :style="{backgroundImage : `Url(${strUrl})`}"></div>
        <div class="filters">
            <FilterBox :strUrl="strUrl" v-for="filter in Filter" :key="filter" :filter="filter">
                <span>{{ filter }}</span>
            </FilterBox>
        </div>
    </div>

   <!-- step == 2 일때 : 필터적용 이미지를 저장-->
    <div v-if="step == 2">
    <div :class="`${newFilter} upload-image`" :style="{backgroundImage : `Url(${strUrl})`}"></div>
    <div class="write">
        <textarea @change="$emit('write',$event.target.value)" class="write-box">
            write!
        </textarea>
    </div>
    </div>
</template>

<script>
import Post from './Post.vue';
import FilterBox from './FilterBox.vue'
import Filter from '../assets/filter.js'

export default {
    name : "ContainerVue",

    data(){
        return{
            Filter,
            newFilter : '',

        }
    },
    mounted(){
        this.emitter.on('changeFilter',(filter)=>{
            this.newFilter = filter;
        // console.log(this.newFilter);
        })
        
    },

    components : {
        Post,
        FilterBox
    },

    props : {
        postData : Array,
        step : Number,
        strUrl : String,

    }
}
</script>

<style>
    @import "../assets/css/container.css";
</style>