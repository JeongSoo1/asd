export default
[
    {
      name: "Kim Hyun",
      userImage: "https://picsum.photos/100?random=3",
      postImage: "https://picsum.photos/600?random=3",
      likes: 36,
      date: "May 15",
      liked: false,
      content: "오늘 무엇을 했냐면요 아무것도 안했어요 ?",
      filter: "perpetua"
    },
    {
      name: "John Doe",
      userImage: "https://picsum.photos/100?random=4",
      postImage: "https://picsum.photos/600?random=4",
      likes: 20,
      date: "Apr 20",
      liked: false,
      content: "흔한 자랑스타그램",
      filter: "clarendon"
    },
    {
      name: "Minny",
      userImage: "https://picsum.photos/100?random=5",
      postImage: "https://picsum.photos/600?random=5",
      likes: 49,
      date: "Apr 4",
      liked: false,
      content: "우리집 개는 화장실 물도 내림",
      filter: "lofi"
    }
  ]