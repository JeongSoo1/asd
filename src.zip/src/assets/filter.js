export default[
    "aden", "_1977", "brannan", "brooklyn", "clarendon", 
"earlybird", "gingham", "hudson", "inkwell", "kelvin", 
"lark", "lofi", "maven", "mayfair", "moon", "nashville", 
"perpetua", "reyes", "rise", "slumber", "stinson", 
"toaster", "valencia", "walden", "willow", "xpro2"
]
