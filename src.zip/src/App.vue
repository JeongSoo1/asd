<template>
  <div class="header" >
    <ul class="header-button-left" v-if="step > 0 " @click="step = 0; ">
      <li>Cancel</li>
    </ul>
    <ul class="header-button-right" >
      <li v-if="step == 1" @click="step++">Next</li>
      <li v-if="step == 2" @click="publish">발행</li>
    </ul>
    <img src="./assets/logo.png" alt="" class="logo">
  </div>
  
  <Container :postData="postData" :step="step" :strUrl="strUrl" @write="strWrite = $event"/>
  <!-- {{ strWrite }} -->
  
  <button @click="more" v-if="step == 0">더보기</button>
  <div class="footer" v-if="step == 0">
    <ul class="footer-button-plus">
      <input @change="upload" type="file" id="file" class="inputfile">
      <label for="file" class="input-plus">+</label>
    </ul>
  </div>
  <!-- <div v-if="step == 0 ">내용 0</div>
  <div v-if="step == 1 ">내용 1</div>
  <div v-if="step == 2 ">내용 2</div>
  <button @click="step=0">버튼 0</button>
  <button @click="step=1">버튼 1</button>
  <button @click="step=2">버튼 2</button> -->
</template>

<script>
import postData from "./assets/data.js";
import Container from "./components/Container.vue";
import axios from "axios";

export default {
  name: 'App',
  data(){
    return{
      postData,
      step : 0,
      strUrl : '',
      strWrite : '',
      newFilter : '',

    }
  },

  components: {
    Container
  },

  mounted(){
    // this.emitter.on("fire",(msg)=>{
    //   console.log(msg)
    // })
    this.emitter.on("changeFilter",(filter)=>{
      this.newFilter = filter;
    })
  },

  methods : {
    publish(){
      this.step = 0;
      let today = new Date().toDateString();
      let newPosting = {
      name: "권정수",
      userImage: "https://picsum.photos/100?random=3",
      postImage: this.strUrl,
      likes: 0,
      date: today,
      liked: false,
      content: this.strWrite,
      filter: this.newFilter
      };
      this.postData.unshift(newPosting)
    },
    upload(e){
      this.step = 1;
      let imgFile = e.target.files;
      this.strUrl = URL.createObjectURL(imgFile[0]);
      console.log(this.strUrl)
    },
    more(){
      axios.get('http://43.200.87.25/api/more')
      .then((result)=>{
        // console.log(result.data);
        for(let i=0; i < result.data.length; i++){
          this.postData.push(result.data[i]);
          // unshift 맨앞
        }
      })
      // axios.post('URL',{name : 'min'})
      // .then()
      // .catch((err)=>{
      //   alert(err)
      // })
    },
  }
}
</script>

<style>
  @import "./assets/css/app.css";
</style>
