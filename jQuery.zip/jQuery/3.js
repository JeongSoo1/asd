$(document).ready(function(){
    $("h1").on({
        click : function(){$(this).css("background-color", "skyblue");},
        mouseenter : function(){$(this).css("background-color", "yellow");},
        mouseleave : function(){$(this).css("background-color", "pink");},
    })


    $(".outer").mouseover(function(){
        console.log("Outer MouseOver Event...")
    })

    $(".outer").mouseenter(function(){
        console.log("Outer MouseEnter Event...")
    })

    $("form input[name = subject]").focus(function(){
        $(this).css("background-color", "pink")
    })
    $("form input[name = subject]").blur(function(){
        $("form input[name = subject]").css("background-color", "yellow")
    })


    $("form input[type = password]").focus(function(){
        $("form input[type = password]").css("background-color", "gold")
    })
    $("form input[type = password]").blur(function(){
        $("form input[type = password]").css("background", "none")
    })

})