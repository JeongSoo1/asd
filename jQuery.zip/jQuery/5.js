$(document).ready(function(){
    $("#btn_menu").on("click" , function(){
        $(".div_menu").slideToggle('slow')
    })

    $("p").on("click",function(){
        $(this)
            .css("color", "red")
            .slideUp(1000)
            .slideDown(1000)
    })
})