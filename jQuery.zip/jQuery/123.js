


$(document).ready(function(){

    if($(this).val() == "" ){
        alert("주소를 먼저 검색하세요")
        $(this).focus;
    }else{
        new daum.Postcode({
        oncomplete: function(data) {
            $("#address_kakao").val(data.address);
        // 팝업에서 검색결과 항목을 클릭했을때 실행할 코드를 작성하는 부분입니다.
        // 예제를 참고하여 다양한 활용법을 확인해 보세요.
        }
    }).open();

    }
});



$(document).ready(function(){
    $("#address_kakao").on("click",()=>{
        if($(this).val() == "" ){
            alert("주소를 먼저 검색하세요")
            $(this).focus;
        }else{
        new daum.Postcode({
            oncomplete: function(data) {
                $("#address_kakao").val(data.address);
            // 팝업에서 검색결과 항목을 클릭했을때 실행할 코드를 작성하는 부분입니다.
            // 예제를 참고하여 다양한 활용법을 확인해 보세요.
            }
        }).open();
    }
    });

    $("#btn-save").on("click",()=>{
        if($("#address_kakao").val() == "" ){
            alert("주소를 먼저 검색하세요")
            $("#address_kakao").focus;
        }
    })
});