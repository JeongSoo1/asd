$(document).ready(function(){
    $("#btn_get").on("click", function(){
        alert($("#message").text());
        alert($("#message").html());
    })

    $("#getName").on("click",function(){
        alert($("#kor_name").val())
    })

    $("#setName").on("click", ()=>{
        $("#eng_name").val("Jang WonYoung")
    })

    $("#attr_get").on("click",()=>{
        let daumUrl = $("#daum").attr("href")
        $("#getDaumURL").val(daumUrl)
    })

    $("#btn_change_name").on("click", ()=>{
        let strHtml = "<b>장원영</b>";
        $("#idolName").html(strHtml)
    })

    $("#btn_ive").on("click", ()=>{
        // let strName = '안녕하세요 ' + $("#ive").text()+'입니다.';
        // $("#ive").text(strName);

        $("#ive").text(function(i, originText){
            return '안녕하세요 ' + originText +'입니다.'
        });
    })

    $("#btn_girl_group").on("click", ()=>{
        $(".girl-group").text(function(i, originText){
            return '안녕하세요 ' + originText + '입니다. ('+i+')'
        });
    })

    $("#btn_change_site").on("click", ()=>{
        let strNaver = "https://naver.com"
        $("#site").text("네이버").attr('href', strNaver);
    })
})