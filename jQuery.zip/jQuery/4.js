$(document).ready(function(){
    // $("#a").fadeIn();

    $("#btn_fadeIn").on("click", function(){
        $("#a").fadeIn(1000);
        $("#b").fadeIn('slow', function(){
            alert('다 끝났어요');
        });
        $("#c").fadeIn('fast');

    })
})