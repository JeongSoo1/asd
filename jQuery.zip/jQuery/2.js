$(document).ready(function(){
    $("button").click(function(){
        $(".intro").css("background-color", "red")
    });

    $("#btn_1").click(function(){
        $("ul li:first-child").css("background-color", "yellow")
    });

    $("#daum_select").click(function(){
        $("a[href = 'https://www.daum.net']").css("background-color", "gold")
    })

    $("#btn_3").click(function(){
        $("table tr:odd").css("background-color", "tomato")
    
    })
})

